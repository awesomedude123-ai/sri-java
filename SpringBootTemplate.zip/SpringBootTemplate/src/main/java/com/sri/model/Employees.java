package com.sri.model;

import java.util.ArrayList;
import java.util.List;

public class Employees {
	private List<Employee> employeeList;
	
	public List<Employee> getEmployeeList(){
		if(employeeList==null) {
			employeeList = new ArrayList<Employee>();
		}
		return employeeList;
	}// end getEmployeeList method
	
	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}// end setEmployeeList method
	public int getCount() {
		if(employeeList!= null)
			return employeeList.size();
		else
			return 0;
	}// end getCount method

}// end public classs
