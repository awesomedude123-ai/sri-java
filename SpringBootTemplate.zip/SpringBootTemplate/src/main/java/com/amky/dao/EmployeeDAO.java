/**
 * 
 */
package com.amky.dao;

import com.sri.model.Employee;
import com.sri.model.Employees;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

/**
 * @author ramsm
 *
 */
@Repository
public class EmployeeDAO {
	private static Employees list = new Employees();
//Spring Boot will create and configure DataSource and JDBCTemplate
	//To use it, just @AutoWired, UI=User Interface
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public Employees getAllEmployees() {
		List employeeListFromQuery;
		employeeListFromQuery= jdbcTemplate.query(
				"select* from employee.employee",
				(rs,rowNum) ->
						new Employee(
								rs.getInt("id"),
								rs.getString("firstName"),
								rs.getString("lastName"),
								rs.getString("address"),
								rs.getString("city"),
								rs.getString("zip")
								)
				);
		list.setEmployeeList(null);
		for(int i=0; i<employeeListFromQuery.size();i++) {
			list.getEmployeeList().add((Employee)employeeListFromQuery.get(i));
			System.out.println(employeeListFromQuery.get(i).toString());
		}
		return list;
	}
}
