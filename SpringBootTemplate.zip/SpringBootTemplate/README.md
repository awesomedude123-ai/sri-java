mvn spring-boot:run# springRESTJDBC
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/makpclasses/springRESTJDBC.git
git push -u origin master

